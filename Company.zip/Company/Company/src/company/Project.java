package company;

import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Label;
import java.awt.List;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static company.SqlConncetion.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ButtonGroup;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.text.MaskFormatter;
enum Gender{
    MALE("Male"),FEMALE("Female");
    private String val;
    Gender(String val){
        this.val=val;
    }
    String getVal(){
        return val;
    }
}
public class Project extends Frame implements ActionListener{
  
    String n,a,g,b;
    Integer m,i;
    double s;
    String nde,lde,gde;
    Integer ide;
    String nda,lda,mda;
    String np,lp;
 List employeel=new List() ;  
      List dependentl=new List() ;  
    List departmentl=new List() ;  
     List projectl=new List() ; 
     Gender selectedGender;
     
     
 Frame e=new Frame();   
 
JFrame employee=new JFrame();
JFrame dependent=new JFrame();
Frame department=new Frame();
 Frame project=new Frame();

    Button insert=new Button("insert");
    Button update=new Button("update"); 
    Button delete=new Button("delete");
    Button search=new Button("search");
      
    Button employeee=new Button("employee");
    Button dependente=new Button("dependent"); 
    Button departmente=new Button("deparment");
    Button projecte=new Button("project");
    
    Button backe=new Button("back");
     Button backde=new Button("back");
      Button backda=new Button("back");
       Button backp=new Button("back");
       
       Button exit=new Button("exit");
        Button exite=new Button("exit");
         Button exitde=new Button("exit");
          Button exitda=new Button("exit");
           Button exitp=new Button("exit");
       
    
      Button insertde=new Button("insert");
    Button updatede=new Button("update"); 
    Button deletede=new Button("delete");
    Button searchde=new Button("search");
      
      Button insertda=new Button("insert");
    Button updateda=new Button("update"); 
    Button deleteda=new Button("delete");
    Button searchda=new Button("search");
    
      Button insertp=new Button("insert");
    Button updatep=new Button("update"); 
    Button deletep=new Button("delete");
    Button searchp=new Button("search");
    
    Label namel=new Label("Name");
    Label addressl=new Label("Address");
    Label salaryl=new Label("Salary");
    Label genederl=new Label("Gender");
   Label brithdatel=new Label("Brithdate");
   Label mangerstartl=new Label("Mangerstart");
  Label idl= new Label("ID");
   
   Label namede=new Label("Name");
    Label idde=new Label("ID");
     Label genderde=new Label("Gender");
      Label locationde=new Label("Birthdate");
      
      Label namelda=new Label("Name");
      Label locationlda=new Label("Location");
      Label mangerstartdatelda=new Label("Manger start date");
      
      Label namelp=new Label("Name");
      Label locationlp=new Label("Location");
     
  
    ButtonGroup test=new ButtonGroup();
    TextField  namet =new TextField();
    TextField  addresst =new TextField();
    TextField  salaryt =new TextField();
    JRadioButton genderbuttons[]=new JRadioButton[Gender.values().length];
    TextField genedert =new TextField();
    JFormattedTextField brithdatet =new JFormattedTextField(createFormatter("####/##/##"));
    TextField  mangerstartt =new TextField();
    TextField  idt =new TextField();
   
   
    TextField  namelde =new TextField();
    TextField  idlde =new TextField();
    TextField  genderlde =new TextField();
    JRadioButton genderbuttons1[]=new JRadioButton[Gender.values().length];
    JFormattedTextField locationlde=new JFormattedTextField(createFormatter("####/##/##"));
    
    TextField nametda=new TextField();
    TextField locationtda=new TextField();
    TextField mangerstartdateda=new TextField();
    
    TextField nametp=new TextField();
    TextField locationtp=new TextField();
    
    Project()
    {
        
         e.  setLayout(null);
       e.setBounds(100, 100, 800, 600);
          e.setBackground(Color.LIGHT_GRAY);
          e.add(employeee);
          e.add(dependente);
          e.add(departmente);
          e.add(projecte);
      
        employeee.setBounds(50, 250, 100, 30);
        dependente.setBounds(180, 250, 100, 30);
        departmente.setBounds(310, 250, 100, 30);
        projecte.setBounds(440, 250, 100, 30);
          
//1frame
         employee.setLayout(null);
         employee.setBounds(100, 100, 800, 600);
         employee.setBackground(Color.LIGHT_GRAY);
          
          dependent. setLayout(null);
       dependent.setBounds(100, 100, 800, 600);
          dependent. setBackground(Color.LIGHT_GRAY);
       
          department.  setLayout(null);
       department.setBounds(100, 100, 800, 600);
          department. setBackground(Color.LIGHT_GRAY);
          
          project.  setLayout(null);
       project.setBounds(100, 100, 800, 600);
          project. setBackground(Color.LIGHT_GRAY);
          
         backe.setBounds(560, 250, 100, 30);
backde.setBounds(560, 250, 100, 30);
backda.setBounds(560, 250, 100, 30);
backp.setBounds(560, 250, 100, 30);

backe. setBackground(Color.blue);
backde. setBackground(Color.blue);
backda. setBackground(Color.blue);
backp. setBackground(Color.blue);



exit.setBounds(566, 300, 100, 30);
exite.setBounds(566, 300, 100, 30);
exitde.setBounds(566, 300, 100, 30);
exitda.setBounds(566, 300, 100, 30);
exitp.setBounds(566, 300, 100, 30);

exit. setBackground(Color.red);
exite. setBackground(Color.red);
exitde. setBackground(Color.red);
exitda. setBackground(Color.red);
exitp. setBackground(Color.red);


          
namel.setBounds(50, 50, 100, 30); 
        addressl.setBounds(50, 100, 100, 30);
        salaryl.setBounds(50, 150, 100, 30);
        genederl.setBounds(300, 50, 100, 30); 
        brithdatel.setBounds(300, 100, 100, 30);
        mangerstartl.setBounds(300, 150, 100, 30);
        idl.setBounds(300, 200, 100, 30);

 namet.setBounds(160, 50, 100, 30);
        addresst.setBounds(160, 100, 100, 30);
        salaryt.setBounds(160, 150, 100, 30);
        genedert.setBounds(410, 50, 100, 30);
        brithdatet.setBounds(410, 100, 100, 30); 
        mangerstartt.setBounds(410, 150, 100, 30);
        idt.setBounds(410, 200, 100, 30);
        locationlde.addFocusListener(new FocusListener() {
    @Override
    public void focusGained(FocusEvent e) {
        // Set placeholder text when the field gains focus
        if (locationlde.getText().isEmpty()) {
            locationlde.setText("YYYY/MM/DD");
            locationlde.setForeground(Color.GRAY); // Set placeholder text color
        }
    }

    @Override
    public void focusLost(FocusEvent e) {
        // Clear placeholder text when the field loses focus
        if (locationlde.getText().equals("YYYY/MM/DD")) {
            locationlde.setText("");
            locationlde.setForeground(Color.BLACK); // Reset text color
        }
    }
});

    namede.setBounds(50, 50, 100, 30); 
      idde .setBounds(50, 100, 100, 30);
      genderde .setBounds(50, 150, 100, 30);
        locationde.setBounds(300, 50, 100, 30);
        
      namelde  .setBounds(160, 50, 100, 30);
    idlde .setBounds(160, 100, 100, 30);
     //genderlde .setBounds(160, 150, 100, 30);
        locationlde.setBounds(410, 50, 100, 30);
        
         namelda.setBounds(50, 50, 100, 30); 
      locationlda .setBounds(50, 100, 100, 30);
      mangerstartdatelda .setBounds(50, 150, 100, 30);
      
       nametda  .setBounds(160, 50, 100, 30);
   locationtda   .setBounds(160, 100, 100, 30);
 mangerstartdateda .setBounds(160, 150, 100, 30);
 
         namelp.setBounds(50, 50, 100, 30); 
      locationlp .setBounds(50, 100, 100, 30);
 
       nametp .setBounds(160, 50, 100, 30);
   locationtp  .setBounds(160, 100, 100, 30);
   
insert.setBounds(50, 250, 100, 30);
        update.setBounds(180, 250, 100, 30);
        delete.setBounds(310, 250, 100, 30);
        search.setBounds(440, 250, 100, 30);

        employeel.setBounds(50, 300, 500, 200);
       dependentl .setBounds(50, 300, 500, 200);
       departmentl.setBounds(50, 300, 500, 200);
        projectl.setBounds(50, 300, 500, 200);
    
    insertde.setBounds(50, 250, 100, 30);
        updatede.setBounds(180, 250, 100, 30);
        deletede.setBounds(310, 250, 100, 30);
        searchde.setBounds(440, 250, 100, 30);
        
        insertda.setBounds(50, 250, 100, 30);
        updateda.setBounds(180, 250, 100, 30);
        deleteda.setBounds(310, 250, 100, 30);
        searchda.setBounds(440, 250, 100, 30);
        
        insertp.setBounds(50, 250, 100, 30);
        updatep.setBounds(180, 250, 100, 30);
        deletep.setBounds(310, 250, 100, 30);
        searchp.setBounds(440, 250, 100, 30);
        
        
       insert.setBackground(Color.GRAY);     
       update.setBackground(Color.GRAY);
       delete.setBackground(Color.GRAY);
        search.setBackground(Color.GRAY);
        
         insertde.setBackground(Color.GRAY);     
       updatede.setBackground(Color.GRAY);
       deletede.setBackground(Color.GRAY);
        searchde.setBackground(Color.GRAY);
        
         insertda.setBackground(Color.GRAY);     
       updateda.setBackground(Color.GRAY);
       deleteda.setBackground(Color.GRAY);
        searchda.setBackground(Color.GRAY);
        
        insertp.setBackground(Color.GRAY);     
        updatep.setBackground(Color.GRAY);
        deletep.setBackground(Color.GRAY);
        searchp.setBackground(Color.GRAY);
            
        employeee.addActionListener(this);
        dependente.addActionListener(this);
        departmente.addActionListener(this);
        projecte.addActionListener(this);
        
       
         //1frame 
        insert.addActionListener(this);
        update.addActionListener(this);
        delete.addActionListener(this);
        search.addActionListener(this);
        
        salaryt.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!(Character.isDigit(c) || c == '.' || c == KeyEvent.VK_BACK_SPACE || c == KeyEvent.VK_DELETE)) {
                    e.consume();
                }
            }
        });
        brithdatet.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!(Character.isDigit(c) || c == '-' || c == KeyEvent.VK_BACK_SPACE || c == KeyEvent.VK_DELETE)) {
                    e.consume();
                }
            }
        });

        brithdatet.addFocusListener(new FocusListener() {
    @Override
    public void focusGained(FocusEvent e) {
        // Set placeholder text when the field gains focus
        if (brithdatet.getText().isEmpty()) {
            brithdatet.setText("YYYY/MM/DD");
            brithdatet.setForeground(Color.GRAY); // Set placeholder text color
        }
    }

    @Override
    public void focusLost(FocusEvent e) {
        // Clear placeholder text when the field loses focus
        if (brithdatet.getText().equals("YYYY/MM/DD")) {
            brithdatet.setText("");
            brithdatet.setForeground(Color.BLACK); // Reset text color
        }
    }
});
          insertde.addActionListener(this);
        updatede.addActionListener(this);
        deletede.addActionListener(this);
        searchde.addActionListener(this);
        
          insertda.addActionListener(this);
        updateda.addActionListener(this);
        deleteda.addActionListener(this);
        searchda.addActionListener(this);
        
          insertp.addActionListener(this);
        updatep.addActionListener(this);
        deletep.addActionListener(this);
        searchp.addActionListener(this);
        
        exit.addActionListener(this);
        exitde.addActionListener(this);
        exitda.addActionListener(this);
        exitp.addActionListener(this);
       exite .addActionListener(this);
         backp.addActionListener(this);
       backde.addActionListener(this);
        backe.addActionListener(this);
        backda.addActionListener(this);
        
        
       e.add(exit);
       employee.add(backe);
        employee.add(exite);
        dependent.add(exitde);
        dependent.add(backde);
        department.add(exitda);
        department.add(backda);
        project.add(exitp);
        project.add(backp);
       
     //1frame        
     employee.add(insert);
    employee. add(update);
    employee.add(delete);
   employee.add(search);
   
    dependent.add(insertde);
    dependent. add(updatede);
    dependent.add(deletede);
   dependent.add(searchde);
   
   department.add(insertda);
    department. add(updateda);
    department.add(deleteda);
   department.add(searchda);
   
   project.add(insertp);
    project. add(updatep);
    project.add(deletep);
   project.add(searchp);
   
    employee.add(employeel);
    dependent.add(dependentl);
    department.add(departmentl);
    project.add(projectl);
    
    project.add(namelp);
    project.add(locationlp);
    
    project.add(nametp);
    project.add(locationtp);
    
    department.add(namelda);
    department.add(locationlda);
    department.add(mangerstartdatelda);
    
    department.add(nametda);
    department.add(locationtda);
    department.add( mangerstartdateda);
    
dependent.add(  namelde);
dependent.add(  idlde);
dependent.add( genderlde);
dependent.add( locationlde);

    dependent.add(  namede);
dependent.add(  idde);
dependent.add( genderde);
dependent.add( locationde);
    
       //1frame
        employee.  add(namel); 
        employee.   add(addressl);
         employee.  add( salaryl);
         employee.  add( genederl); 
        employee.  add( brithdatel); 
        employee.   add( mangerstartl);
        employee.add(idl);
       //1frame
        employee.   add(namet); 
          employee. add( addresst);
        employee.   add(salaryt);
        //employee.   add( genedert);
          employee. add( brithdatet);
         employee.  add( mangerstartt);
             employee.add(idt);
         for(int it=0;it<Gender.values().length;it++){
             Gender gender=Gender.values()[it];
             genderbuttons[it]=new JRadioButton(gender.getVal());
             genderbuttons[it].setBounds(410+it*70, 50, 70, 30);
             genderbuttons[it].addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    selectedGender = gender;
                }
            });
             test.add(genderbuttons[it]);
             employee.add(genderbuttons[it]);
         }
         for(int it=0;it<Gender.values().length;it++){
             Gender gender=Gender.values()[it];
             genderbuttons1[it]=new JRadioButton(gender.getVal());
             genderbuttons1[it].setBounds(160+it*100, 150, 100, 30);
             genderbuttons1[it].addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    selectedGender = gender;
                }
            });
             test.add(genderbuttons1[it]);
             dependent.add(genderbuttons1[it]);
         }
   
          e. setVisible(true);
       employee. setVisible(false);
     dependent.setVisible(false);
           department.setVisible(false);
           project.setVisible(false);
       
    }
    
    public static void main(String[] args) {
      Project p=new Project();
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
      if (ae.getSource() == insert) {
          connect();
          n= namet.getText();
          a=addresst.getText();
          s=Double.parseDouble(salaryt.getText());
          g=selectedGender.getVal();
          b=brithdatet.getText();
         String mangerstartText = mangerstartt.getText();
          if (!mangerstartText.isEmpty()) {
             m = Integer.valueOf(mangerstartText);
          } else {
             m = null;
          }

           employeel.add("id: "+i);
           employeel.add(   "Name: " + n );
          employeel.add("Address: " + a );
          employeel.add( "Salary: " + s );
          employeel.add( "Gender: " + g);
            employeel.add("Birthdate: " + b );
            employeel.add( "Manager Start: " + m);
          try {
               if(m!=null) insert("Employee","Name",n,"Address",a,"Salary",s,"Gender",g,"BirthDate",b,"SupervisorEmployeeID",m);
               else insert("Employee","Name",n,"Address",a,"Salary",s,"Gender",g,"BirthDate",b);
          } catch (ClassNotFoundException ex) {
              Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
          }
            System.out.println("Insert button clicked");
        disconnect();
        } else if (ae.getSource() == update) {
            connect();
    String updatedName = namet.getText(); 
    String updatedAddress = addresst.getText();
    double updatedSalary = Double.parseDouble(salaryt.getText());
    Integer idToUpdate = Integer.valueOf(idt.getText());

    
    for (int i = 0; i < employeel.getItemCount(); i++) {
      
        String listItem = employeel.getItem(i);

       
        if (listItem.contains("ID: " + idToUpdate)) {
          
            listItem = "ID: " + idToUpdate + ", Name: " + updatedName + ", Address: " + updatedAddress + ", Salary: " + updatedSalary;
          
            employeel.replaceItem(listItem, i);
           
            break;
        }
    }
             try {
                  SqlConncetion.update("EmployeeID = "+idToUpdate,"Employee","Name",updatedName,"Address",updatedAddress,"Salary",updatedSalary);
             } catch (ClassNotFoundException ex) {
              Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
          }
            System.out.println("Update button clicked");
            disconnect();
        } else if (ae.getSource() == delete ){
            connect();
          namet  .setText(" ");
         addresst .setText(" ");
          salaryt.setText(" ");
         genedert .setText(" ");
         brithdatet .setText(" ");
         mangerstartt .setText(" ");
         String idText = idt.getText();
          if (!idText.isEmpty()) {
             i = Integer.valueOf(idText);
          } else {
             i = null;
          }
          i=Integer.valueOf(idt.getText());
          idt.setText("");
           try {
               SqlConncetion.delete("Employee","EmployeeID = "+i);
          } catch (ClassNotFoundException ex) {
              Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
          }
           disconnect();
     
        } else if (ae.getSource() ==search) {
            connect();
            namet.setText(n);
            addresst .setText(a);
            String sString = String.valueOf(s);
           salaryt.setText(sString);
         genedert.setText(g);
         brithdatet.setText(b);
         
         mangerstartt.setText(String.valueOf(m));
         i=Integer.valueOf(idt.getText());
          try {
                var li = SqlConncetion.select("Employee", "EmployeeID = "+i);
                for(var k : li){
                    for(var field:k.entrySet()){
                      String[] lines=field.toString().split("\n");
                      for(String line:lines){
                          employeel.add(line);
                      }
                    }
                }
          } catch (ClassNotFoundException ex) {
              Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
          }
          disconnect();
 }
        else if(ae.getSource()==employeee){
            e.setVisible(false);
           employee .setVisible(true);
           dependent.setVisible(false);
           department.setVisible(false);
           project.setVisible(false);
            
        }
       else if(ae.getSource()==dependente){
              e.setVisible(false);
           employee .setVisible(false);
           dependent.setVisible(true);
           department.setVisible(false);
           project.setVisible(false);
            
        }
       else if(ae.getSource()==departmente){
             e.setVisible(false);
           employee .setVisible(false);
           dependent.setVisible(false);
           department.setVisible(true);
           project.setVisible(false);
            
            
        } else if(ae.getSource()==projecte){
              e.setVisible(false);
           employee .setVisible(false);
           dependent.setVisible(false);
           department.setVisible(false);
           project.setVisible(true);
            
        } else  if (ae.getSource() == insertde) {
            connect();
         nde=namelde.getText();
         lde=locationlde.getText();
        gde=selectedGender.getVal();
        
        dependentl.add("Name: "+nde);
        dependentl.add("Birthdate: "+lde);
        dependentl.add("id: "+ide);
        dependentl.add("Gender: "+gde);
          try {
              insert("Dependant","Name",nde,"BirthDate",lde,"Gender",gde);
          } catch (ClassNotFoundException ex) {
              Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
          }
          
        
        } else if (ae.getSource() == updatede) {
   connect();
    String updatedName = namelde.getText();
    String updatedLocation = locationlde.getText();
    Integer updatedId = Integer.valueOf(idlde.getText());
    String updatedGender = genderlde.getText();
    
  
    String idToUpdate = idlde.getText();
    
          
    for (int i = 0; i < dependentl.getItemCount(); i++) {
        String listItem = dependentl.getItem(i);
        
        
        if (listItem.contains("ID: " + idToUpdate)) {
            String updatedItem = "ID: " + updatedId + ", Name: " + updatedName + ", Location: " + updatedLocation + ", Gender: " + updatedGender;
            
        
            dependentl.replaceItem(updatedItem, i);

           
            break;
        }
    }
          try {
              SqlConncetion.update("DependantID = "+updatedId,"Dependant","Name",updatedName,"BirthDate",updatedLocation,"Gender",updatedGender);
          } catch (ClassNotFoundException ex) {
              Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
          }
  disconnect();
        }  else if (ae.getSource() == deletede ){
         connect();
            namelde.setText("");
            locationlde.setText("");
            String idText = idlde.getText();
          if (!idText.isEmpty()) {
             ide = Integer.valueOf(idText);
          } else {
             ide = null;
          }
            idlde.setText("");
            genderlde.setText("");
          try {
              if(ide!=null) SqlConncetion.delete("Dependant","DependantID = "+ide);
              else SqlConncetion.delete("Dependant");
          } catch (ClassNotFoundException ex) {
              Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
          }
            System.out.println("Delete button clicked");
           disconnect();
        } else if (ae.getSource() ==searchde) {
            connect();
            namelde.setText(nde);
            locationlde.setText(lde);
            ide = Integer.valueOf(idlde.getText());
            idlde.setText(String.valueOf(ide));
            genderlde.setText(gde);
          try {
              var li = SqlConncetion.select("Dependant", "DependantID = "+ide);
              for(var k:li){
                  for(var field:k.entrySet()){
                      String[] lines=field.toString().split("\n");
                      for(String line:lines){
                          dependentl.add(line);
                      }
                  }
                  
              }
          } catch (ClassNotFoundException ex) {
              Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
          }
            System.out.println("Search button clicked");
  
            disconnect();
            
        }else if(ae.getSource() == insertda)
            {
                connect();
                nda=nametda.getText();
                lda=locationtda.getText();
                mda= mangerstartdateda.getText();
          try {
              insert("Department","Name",nda,"Location",lda,"ManagerStartDate",mda);
          } catch (ClassNotFoundException ex) {
              Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
          }
          disconnect();
            }
        else if (ae.getSource() == updateda) {
            connect();
    String updatedName = nametda.getText();
    String updatedLocation = locationtda.getText();
    String updatedStartDate = mangerstartdateda.getText();
    
    Integer idToUpdate = Integer.valueOf(JOptionPane.showInputDialog("Enter Department ID:"));
  
    for (int i = 0; i < dependentl.getItemCount(); i++) {
        String listItem = dependentl.getItem(i);
      
        if (listItem.contains("ID: " + idToUpdate)) {
       
            String updatedItem = "ID: " + idToUpdate + ", Name: " + updatedName + ", Location: " + updatedLocation + ", Start Date: " + updatedStartDate;
      
            dependentl.replaceItem(updatedItem, i);
         
            break;
        }
    }
          try {
              SqlConncetion.update("DepartmentID = "+idToUpdate,"Department","Name",updatedName,"Location",updatedLocation,"ManagerStartDate",updatedStartDate);
          } catch (ClassNotFoundException ex) {
              Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
          }
          disconnect();
}
else if (ae.getSource()==deleteda){
  connect();
            nametda  .setText("");
   locationtda. setText("");
    mangerstartdateda.setText("");
    Integer selecteddaID=Integer.valueOf(JOptionPane.showInputDialog("Enter Department ID:"));
          try {
              SqlConncetion.delete("Department","DepartmentID = "+selecteddaID);
          } catch (ClassNotFoundException ex) {
              Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
          }
          disconnect();
}else if(ae.getSource()==searchda){
    connect();
    nametda.setText(nda);
    locationtda.setText(lda);
    mangerstartdateda.setText(mda);
    Integer selecteddaID=Integer.valueOf(JOptionPane.showInputDialog("Enter Department ID:"));
        try {
              var list=SqlConncetion.select("Department","DepartmentID = "+selecteddaID);
              for(var k:list){
                  for(var field:k.entrySet()){
                      String[] lines=field.toString().split("\n");
                      for(String line:lines){
                          departmentl.add(line);
                      }
                  }
              }
          } catch (ClassNotFoundException ex) {
              Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
          }
        disconnect();
}else if(ae.getSource()==insertp)
{
    connect();
    np=nametp.getText();
    lp=locationtp.getText();
    projectl.add("Name: "+np);
    projectl.add("Location: "+lp);
          try {
              insert("Project","Name",np,"Location",lp);
          } catch (ClassNotFoundException ex) {
              Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
          }
          disconnect();
}
else if(ae.getSource()==deletep){
    connect();
    nametp.setText("");
    locationtp.setText("");
    Integer selecteddaID=Integer.valueOf(JOptionPane.showInputDialog("Enter Project ID:"));
          try {
              SqlConncetion.delete("Project","ProjectID = "+selecteddaID);
          } catch (ClassNotFoundException ex) {
              Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
          }
          disconnect();
}else if(ae.getSource()==searchp){
    connect();
nametp.setText(np);
locationtp.setText(lp);
Integer selecteddaID=Integer.valueOf(JOptionPane.showInputDialog("Enter Project ID:"));
          try {
              var list=SqlConncetion.select("Project","ProjectID = "+selecteddaID);
              for(var k:list){
                  for(var field:k.entrySet()){
                      String[] lines=field.toString().split("\n");
                      for(String line:lines){
                          projectl.add(line);
                      }
                  }
              }
          } catch (ClassNotFoundException ex) {
              Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
          }
          disconnect();
}
else if (ae.getSource() == updatep) {
  connect();
    String updatedName = nametp.getText();
    String updatedLocation = locationtp.getText();
     for (int i = 0; i < projectl.getItemCount(); i += 2) { 
        projectl.replaceItem("Name: " + updatedName, i);
        projectl.replaceItem("Location: " + updatedLocation, i + 1);
    }Integer selecteddaID=Integer.valueOf(JOptionPane.showInputDialog("Enter Project ID:"));
          try {
              SqlConncetion.update("ProjectID = "+selecteddaID,"Project","Name",updatedName,"Location",updatedLocation);
          } catch (ClassNotFoundException ex) {
              Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
          }
          disconnect();}
else if(ae.getSource()==backe)
{
     e. setVisible(true);
       employee. setVisible(false);
     dependent.setVisible(false);
           department.setVisible(false);
           project.setVisible(false);
        
}else if(ae.getSource()==backde)
{
     e. setVisible(true);
       employee.setVisible(false);
     dependent.setVisible(false);
           department.setVisible(false);
           project.setVisible(false);
}
      else if(ae.getSource()==backda)
{
     e. setVisible(true);
       employee. setVisible(false);
     dependent.setVisible(false);
           department.setVisible(false);
           project.setVisible(false);
        
}else if(ae.getSource()==backp)
{
     e. setVisible(true);
       employee. setVisible(false);
     dependent.setVisible(false);
           department.setVisible(false);
           project.setVisible(false);
}
else if(ae.getSource()==exit){
    System.exit(0);
}
else if(ae.getSource()==exite){
    System.exit(0);
}

else if(ae.getSource()==exitde){
    System.exit(0);
}
else if(ae.getSource()==exitda){
    System.exit(0);
}
      
else if(ae.getSource()==exitp){
    System.exit(0);
}
        
    }
private MaskFormatter createFormatter(String format) {
        MaskFormatter formatter = null;
        try {
            formatter = new MaskFormatter(format);
            formatter.setPlaceholderCharacter('_');
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        return formatter;
    }
}