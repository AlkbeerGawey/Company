package company;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.sql.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class SqlConncetion {
    public static Connection con;
    public static void connect(){
        try {
            String url = "jdbc:sqlserver://LAPTOP-5VTK7DPH\\SQLEXPRESS;databaseName=Company;trustServerCertificate=true;integratedSecurity=true;";
            String sqlUserName="user1";
            String sqlPassword="1234";
            con = DriverManager.getConnection(url,sqlUserName,sqlPassword);
            JOptionPane.showMessageDialog(null,"CONNECTED");
        } catch (SQLException ex) {
            Logger.getLogger(SqlConncetion.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null,"Error CONNECTION");
        }
    }
    public static void disconnect(){
        try {
            if (con != null){
                con.close();
                JOptionPane.showMessageDialog(null,"DISCONNECTED");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Error CONNECTION");
        }
    }
    public static List<Map<String, Object>> select(String tableName, String whereCondition,String... attributes) throws ClassNotFoundException {
        String query=null;
        List<Map<String, Object>> selectedRecord=new ArrayList<>();
        if(attributes.length==0||(attributes[0].equals("*"))){
            query = "select * from " + tableName;
        }
        else{
            String attributesList = String.join(",", attributes);
            query = "select " + attributesList + " from " + tableName;
        }
        if(whereCondition!=null){
            query+=" where "+whereCondition;
        }
        try {
            Statement state = con.createStatement();
            ResultSet rs = state.executeQuery(query);
            while (rs.next()) {
                ResultSetMetaData rsmd = rs.getMetaData();
                int columnCount = rsmd.getColumnCount();
                Map<String, Object> recordD=new HashMap<>();
                for (int i = 1; i <= columnCount; i++) {
                    String columnName = rsmd.getColumnName(i);
                    Object val = rs.getObject(i);
                    recordD.put(columnName,val);
                    System.out.println(columnName + ": " + val);
                }
                selectedRecord.add(recordD);
                System.out.println();
            }
        } catch (SQLException e) {
            Logger.getLogger(SqlConncetion.class.getName()).log(Level.SEVERE, null, e);
        }
        return selectedRecord;
    }
    public static void insert(Object... data) throws ClassNotFoundException {
        String tableName=(String) data[0];
        StringBuilder columns = new StringBuilder();
        StringBuilder vals = new StringBuilder();
        for (int i = 1; i < data.length; i += 2) {
            columns.append(data[i]).append(", ");
            vals.append("'").append(data[i + 1]).append("', ");
        }
        columns.delete(columns.length() - 2, columns.length());
        vals.delete(vals.length() - 2, vals.length());
        String query = "insert into " + tableName + " (" + columns + ") values (" + vals + ")";
        try {
            Statement state = con.createStatement();
            state.executeUpdate(query);
            JOptionPane.showMessageDialog(null,"data inserted successfully");
        } catch (SQLException ex) {
            Logger.getLogger(SqlConncetion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public static void delete(String tableName, String whereCondition) throws ClassNotFoundException {
        try {
            Statement state = con.createStatement();
            String deleteQuery = "delete from " + tableName;
            if (whereCondition != null) {
                deleteQuery += " where " + whereCondition;
            }
            int rowsAffected = state.executeUpdate(deleteQuery);
            JOptionPane.showMessageDialog(null,rowsAffected + " rows deleted successfully");
        } catch (SQLException ex) {
            Logger.getLogger(SqlConncetion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public static void delete(String tableName) throws ClassNotFoundException {
        delete(tableName, null);
    }
    public static void update(String whereCondition, Object... attributes) throws ClassNotFoundException {
        String tableName=(String) attributes[0];
        StringBuilder recordings = new StringBuilder();
        if(attributes.length>2){
        for (int i = 1; i < attributes.length; i += 2) {
            recordings.append(attributes[i]).append(" = '").append(attributes[i + 1]).append("', ");
        }
        String sets = recordings.substring(0, recordings.length() - 2);
        try {
            Statement state = con.createStatement();
            String updateQuery = "update " + tableName + " set " + sets;
            if (whereCondition != null) {
                updateQuery += " where " + whereCondition;
            }
            state.executeUpdate(updateQuery);
            JOptionPane.showMessageDialog(null,"Data updated successfully");
        } catch (SQLException ex) {
            Logger.getLogger(SqlConncetion.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null,"Unable To Update Data","Modification",JOptionPane.ERROR_MESSAGE);
        }
    }  
    }
}